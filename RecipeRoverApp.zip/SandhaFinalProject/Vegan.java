                                        /**********************************************************************
                                        ***  Project Name : CS 200 Programming Assignment (Final Project)   ***
                                        ***  Author       : Seerat Sandha                                   ***
                                        ***  Date         : 12/08/2023                                      ***
                                        ***********************************************************************/  





import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.util.Comparator;
import java.util.Collections;
import java.awt.GridLayout;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.util.InputMismatchException;
import java.io.BufferedWriter;
import java.io.FileWriter;

 


public class Vegan extends SpecificDietOptionSelected
{
    static JFrame frame = new JFrame("Diet Option"); // seeting the name of the frame
    static JPanel panel = new JPanel();
    static int optionCounter = 1;
    
  public static void initAndShowFXVegan()
  {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1, 1);

        JPanel fxPanel = new JPanel();
        frame.add(fxPanel);

        frame.setVisible(true);
        try
        {
            VeganDishesPrint();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
/* 
 * Method to read the data from the CSV file containing the data for vegan dishes from row 2 to 6.
 * In which row 1 contain the headers. 
 * */
 
    public static void VeganDishesPrint() throws Exception {
    BufferedReader readBuffer = null;
    try {
        String inputLine;
        readBuffer = new BufferedReader(new FileReader("C:\\Users\\sand4927\\SpecificDietData (Sandha).csv"));

        // Reading and ignoring the header row
        readBuffer.readLine();

        ArrayList<ArrayList<String>> data = new ArrayList<>();

        int rowsToDisplay = 5;
        int currentRow = 0;

        while ((inputLine = readBuffer.readLine()) != null && currentRow < rowsToDisplay) {
            ArrayList<String> rowData = CSVtoArrayList(inputLine);
            data.add(rowData);
            currentRow++;
        }

        // Creating a copy of the data for display
        ArrayList<ArrayList<String>> displayData = new ArrayList<>(data);

        // Sorting the display data alphabetically based on dish names
        Collections.sort(displayData, Comparator.comparing(row -> row.get(1), String.CASE_INSENSITIVE_ORDER)); // by stackOverFlow.com
        
        
        // Displaying only the first five vegan dishes with data
        displayDishNames(displayData);

        // Get user input for the selected dish
        //int selectedDishNumber = getUserInput("Enter the number of the dish to view details:");
        boolean checkValidNumber = true;
    try
    {
        while(checkValidNumber)
        {
        int selectedDishNumber = getUserInput("Enter the number of the dish to view details:");

        if (selectedDishNumber >= 1 && selectedDishNumber <=5)
        {
            // Display detailed information for the selected dish
            displayDishDetails(displayData.get(selectedDishNumber - 1));
            checkValidNumber = false;
        } else 
        {
            JOptionPane.showMessageDialog(null, "Invalid dish number. Please try again.");
            throw new Exception("Your input is totally invalid!!");
        }
    }
}
catch( InputMismatchException ie)
{
    System.out.println(ie.getMessage());
    
}
    } catch (IOException e) 
    {
        System.out.println("Ran into an IO error");
        e.printStackTrace();
    } finally 
    {
        try 
        {
            if (readBuffer != null)
            {
                readBuffer.close();
            }
        } catch (IOException readException)
        {
            System.out.println("Ran into an error reading the file");
            readException.printStackTrace();
        }
    }
}


    public static int getUserInput(String message) {
        String userInput = JOptionPane.showInputDialog(null, message);
        return Integer.parseInt(userInput);
    }
    public static String getUserInput2(String message) {
        String userInput = JOptionPane.showInputDialog(null, message);
        return (userInput);
    }

    public static void displayDishNames(ArrayList<ArrayList<String>> data) {
    ArrayList<JLabel> sortedVeganDishes = new ArrayList<>();

    // Sort the data alphabetically based on dish names
    Collections.sort(data, (row1, row2) -> row1.get(1).compareTo(row2.get(1))); // by stackOverFlow.com

    // Display only the first five vegan dishes with data
    for (int i = 0; i < Math.min(data.size(), 5); i++) {
        String namesOnly = data.get(i).get(1);
        JLabel label = new JLabel(" ( " + (i + 1) + ") " + namesOnly + "     ");
        optionCounter++;
        label.setFont(new Font("Agency FB", Font.BOLD, 20)); // setting the font style and size
        sortedVeganDishes.add(label);
    }

    // Add the sorted labels to panel
    SwingUtilities.invokeLater(() -> 
    {
        for (JLabel label : sortedVeganDishes) {
            label.setFont(new Font("Agency FB", Font.BOLD, 20));
            panel.add(label);
        }

        frame.add(panel);

        frame.pack(); // Pack the frame to fit its contents
        frame.setVisible(true);
        frame.setSize(1920, 1080);
        frame.setVisible(true);
    });
}



    public static void displayDishDetails(ArrayList<String> dishData) throws Exception,IOException
    {
    // Clearing the panel before displaying dish details
    panel.removeAll();
    
    
    
    
    // creating the text area to print the data in formated boxes 
    ArrayList<JTextArea> dishDetails = new ArrayList<>();
    dishDetails.add(createTextArea("Prep Time: " + dishData.get(2)));
    dishDetails.add(createTextArea("Cook Time: " + dishData.get(3)));
    dishDetails.add(createTextArea("Total Time: " + dishData.get(4)));
    dishDetails.add(createTextArea("Servings: " + dishData.get(5)));
    dishDetails.add(createTextArea("Ingredients: " + dishData.get(6)));
    dishDetails.add(createTextArea("Directions: " + dishData.get(7)));
   // Set up a GridLayout for the panel
    panel.setLayout(new GridLayout(dishDetails.size(), 1));

    // Add the text areas to the panel
    for (JTextArea textArea : dishDetails) {
        panel.add(new JScrollPane(textArea));
    }

    frame.add(panel);

    frame.pack(); // Pack the frame to fit its contents
    frame.setVisible(true);
    frame.setSize(1920, 1080);
    frame.setVisible(true);
    boolean checkValidSelection = true;
    try
    {
        while(checkValidSelection)
        {
        String selectedDishNumber = getUserInput2("Do you want to store this recipe: Yes/No");

        if (selectedDishNumber.equals("yes"))
        {
            // Display detailed information for the selected dish
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("StoreRecipe.txt", true))) {
            writer.write("Dish Name: " + dishData.get(1) + System.lineSeparator());
            writer.write("Prep Time: " + dishData.get(2) + System.lineSeparator());
            writer.write("Cook Time: " + dishData.get(3) + System.lineSeparator());
            writer.write("Total Time: " + dishData.get(4) + System.lineSeparator());
            writer.write("Servings: " + dishData.get(5) + System.lineSeparator());
            writer.write("Ingredients: " + dishData.get(6) + System.lineSeparator());
            writer.write("Directions: " + dishData.get(7) + System.lineSeparator());
            writer.write("----------------------------------------" + System.lineSeparator());
        
    
            checkValidSelection= false;
        }
    }
        else if(selectedDishNumber.equals("no"))
        {
            JOptionPane.showMessageDialog(null, "You Selected: Not add to file");
            checkValidSelection= false;
        }
         else 
        {
            JOptionPane.showMessageDialog(null, "Invalid Selection. Please try again.");
            throw new Exception("Your input is totally invalid!!");
        }
    }
}
catch( InputMismatchException ie)
{
    System.out.println(ie.getMessage());
    
}
     
}

private static JTextArea createTextArea(String text) {
    JTextArea textArea = new JTextArea(text);
    textArea.setFont(new Font("Arial", Font.PLAIN, 16));
    textArea.setEditable(false);
    textArea.setLineWrap(true);
    textArea.setWrapStyleWord(true);
    return textArea;
}

    // Utility which converts CSV to ArrayList using Split operation
    public static ArrayList<String> CSVtoArrayList(String CSVFileName) {
    ArrayList<String> arrlist = new ArrayList<>();

    if (CSVFileName != null) {
        // Use a regular expression to split the CSV line while ignoring commas within quotes
        String[] splitData = CSVFileName.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);

        for (int i = 0; i < splitData.length; i++) {
            if (splitData[i].length() == 0) {
                splitData[i] = "0";
            }
            if (splitData[i] != null && splitData[i].length() != 0) {
                arrlist.add(splitData[i].trim());
            }
        }
    }
    return arrlist;
}
}
