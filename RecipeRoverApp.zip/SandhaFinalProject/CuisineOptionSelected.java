                                        /**********************************************************************
                                        ***  Project Name : CS 200 Programming Assignment (Final Project)   ***
                                        ***  Author       : Seerat Sandha                                   ***
                                        ***  Date         : 12/08/2023                                      ***
                                        ***********************************************************************/  



import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.control.TextInputDialog;
import java.util.Optional;
import javafx.scene.control.Alert;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class CuisineOptionSelected 
{

    /* if user selected the Cuisine option then initAndShowCusisne () will called in recipe rover class. 
     * In initAndShowCuisine() setting name and size of the frame to full screen.      
    */

    public  static void initAndShowFXCuisine() {
        JFrame frame = new JFrame(" Various Cuisine Options");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1920, 1080);

        JFXPanel fxPanel = new JFXPanel();
        frame.add(fxPanel);

        frame.setVisible(true);

        Platform.runLater(() -> 
        {
            //initFX(fxPanel);
            DialogBoxSelctedValue(fxPanel);
        });
    }

    
    
    private static void DialogBoxSelctedValue(JFXPanel fxPanel)
    {
        Platform.runLater(() -> {
            HBox layout = new HBox(10); // Create an HBox with spacing
            Button button = new Button("");
            // Creating the buttons using the for loop logic 
            for (int i = 1; i <= 7; i++)
            {
                if(i ==1)
                {
                // naming, setting height, width and color of teh buttons
                button = new Button("Mexican") ;
                button.setPrefWidth(200);
                button.setPrefHeight(100);
                button.setStyle("-fx-background-color: slateblue; -fx-text-fill: white;-fx-font-size: 20px;-fx-font-weight: bold;");
  
            }
            if(i ==2)
                {
                button = new Button("Indian") ;
                button.setPrefWidth(200);
                button.setPrefHeight(100);
                button.setStyle("-fx-background-color: #F5BC0F; -fx-text-fill: white;-fx-font-size: 20px;-fx-font-weight: bold;");
            }
            if(i ==3)
                {
                button = new Button("Thai") ;
                button.setPrefWidth(200);
                button.setPrefHeight(100);
                button.setStyle("-fx-background-color:#74AD62; -fx-text-fill: white;-fx-font-size: 20px;-fx-font-weight: bold;");
            }
            if(i ==4)
                {
                button = new Button("Chinese") ;
                button.setPrefWidth(200);
                button.setPrefHeight(100);
                button.setStyle("-fx-background-color: #CF5568; -fx-text-fill: white;-fx-font-size: 20px;-fx-font-weight: bold;");
            }
            if(i ==5)
                {
                button = new Button("Japanese") ;
                button.setPrefWidth(200);
                button.setPrefHeight(100);
                button.setStyle("-fx-background-color: #7CB5BD; -fx-text-fill: white;-fx-font-size: 20px;-fx-font-weight: bold;");
            }
            if(i ==6)
                {
                 button = new Button("American") ;
                 button.setPrefWidth(200);
                 button.setPrefHeight(100);
                 button.setStyle("-fx-background-color: #B5854D; -fx-text-fill: white;-fx-font-size: 18px;-fx-font-weight: bold;");
            }
            if(i ==7)
                {
                button = new Button("Italian") ;
                button.setPrefWidth(200);
                button.setPrefHeight(100);
                button.setStyle("-fx-background-color: #E695FF; -fx-text-fill: white;-fx-font-size: 20px;-fx-font-weight: bold;");
            }

                button.setOnAction(event -> 
                {
                    // Create a TextInputDialog
                    TextInputDialog dialog = new TextInputDialog("");
                    dialog.setTitle("Enter Value");
                    dialog.setHeaderText("Enter your selected option:");
                    dialog.setContentText("Value:");

                    Optional<String> result = dialog.showAndWait();

                    result.ifPresent(value -> {
                        value = value.toLowerCase();
                        if (value.equals("mexican") || value.equals("indian")|| value.equals("thai")|| value.equals("chinese")
                        || value.equals("japanese")|| value.equals("american")|| value.equals("italian"))
                        {
                           
                            // Display a message indicating the selected option
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Option Selected!!");
                            alert.setHeaderText(null);
                            alert.setContentText("You selected: " + value);
                            alert.showAndWait();
                        } else 
                        {
                            // Display a message for an invalid option
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Select Again !!");
                            alert.setHeaderText(null);
                            alert.setContentText("Nothing Selected: " + value);
                            alert.showAndWait();
                        }
                        
                        // calling the methods according to user input.
                        if(value.equals("mexican"))
                        {
                            Mexican.initAndShowFXVegan();
                        }
                        if(value.equals("indian"))
                        {
                            Indian.initAndShowFXIndian();
                        }
                        if(value.equals("thai"))
                        {
                            Thai.initAndShowFXThai();
                        }
                        if(value.equals("chinese"))
                        {
                            Chinese.initAndShowFXChinese();
                        }
                        if(value.equals("japanese"))
                        {
                            Japanese.initAndShowFXJapanese();
                        }
                        if(value.equals("american"))
                        {
                            American.initAndShowFXAmerican();
                        }
                        if(value.equals("italian"))
                        {
                            Italian.initAndShowFXItalian();
                        }
                        
                        
                    });
                    
                });

                layout.getChildren().add(button);
            }

            Scene scene = new Scene(layout, 300, 200);
            fxPanel.setScene(scene);
        });
        
    }
}