
                                        /**********************************************************************
                                        ***  Project Name : CS 200 Programming Assignment (Final Project)   ***
                                        ***  Author       : Seerat Sandha                                   ***
                                        ***  Date         : 12/08/2023                                      ***
                                        ***********************************************************************/   




import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javax.swing.*;
import java.util.Optional;


public class RecipeRover
{
    
    // in main calling the initAndShowFX() method to show the panels on the screen 
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {  // using to perform task 
            initAndShowFX();  // calling initAnd ShowFX() method
        });
    }
    
    // in initAndShowFX() setting the name of the frame, setting size, setting it to visible 
    public static void initAndShowFX() {
        JFrame frame = new JFrame("Welcome!!! To RecipeRover App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1920, 1920);
        JFXPanel fxPanel = new JFXPanel();
        frame.add(fxPanel);

        frame.setVisible(true);

        Platform.runLater(() -> {  // used this to be run on the JavaFX application thread.
            initFX(fxPanel); // calling initFX(fxPanel) 
        });
    }

    
    /* Method for creating Two buttons and calling the methods of classes NoDietOptionSelected & DietOptionSelected
    according to the selection by user. Adding clickable function (using setOnAction) to look over the action taken by user and 
    move to take next steps */
    
    private static void initFX(JFXPanel fxPanel) {
        Platform.runLater(() -> {
            HBox layout = new HBox(10); // Create an HBox with spacing
             
            Button noDietButton = new Button("Cuisines"); 
            // creating and naming the buttons along with using gradient for color blending
            // taking from https://blog.e-zest.com/
            configureButton(noDietButton, 800, 400, "-fx-background-color: linear-gradient(from 0% 20% to 80% 100%,#9328EA,#E103A8,#FF1C53,#FFBE00); -fx-text-fill: white; -fx-font-size: 38px;-fx-font-weight: bold;");

            Button dietButton = new Button("Specific Diet");
            configureButton(dietButton, 800, 400, "-fx-background-color: linear-gradient(from 0% 20% to 80% 100%,#9328EA,#E103A8,#FF1C53,#FFBE00); -fx-text-fill: white; -fx-font-size: 38px;-fx-font-weight: bold;");

            layout.getChildren().addAll(noDietButton, dietButton); 
            //organizing and displaying UI elements within a window.

            Scene scene = new Scene(layout, 300, 200);
            fxPanel.setScene(scene);

            noDietButton.setOnAction(event -> {
                  CuisineOptionSelected.initAndShowFXCuisine(); // calling method 
            });

            dietButton.setOnAction(event -> {
                SpecificDietOptionSelected.initAndShowFXSpecificDiet();  // calling method
            });
        });
    }

    private static void configureButton(Button button, double width, double height, String style) {
        button.setPrefWidth(width);
        button.setPrefHeight(height);
        button.setStyle(style);     //setting length, width and height of the buttons 
    }
}
