

                                        /**********************************************************************
                                        ***  Project Name : CS 200 Programming Assignment (Final Project)   ***
                                        ***  Author       : Seerat Sandha                                   ***
                                        ***  Date         : 12/08/2023                                      ***
                                        ***********************************************************************/     
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.control.TextInputDialog;
import java.util.Optional;
import javafx.scene.control.Alert;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class SpecificDietOptionSelected 
{
    /* if user selected the Diet option then initAndShowSpecificDiet () will called in recipe rover class.
     * In initAndShowSpecificDiet() setting name and size of the frame to full screen.      
    */
    public  static void initAndShowFXSpecificDiet() {
        JFrame frame = new JFrame("Specific Diet Options");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(2000,1080 );

        JFXPanel fxPanel = new JFXPanel();
        frame.add(fxPanel);

        frame.setVisible(true);

        Platform.runLater(() -> 
        {
            //initFX(fxPanel);
            
            DialogBoxSelectedValue(fxPanel);
            
        });
    }

    /* 
     * DialogBoxSelectedValue() Where the three buttons for the diffrent types of recipe options are created for Vegan, Gluten-free
       and Plaeo-diet options.Where a dilaog box will open to take the input from the user according to the user enter value it will call
       approriate method from appropriate class. 
    */
    
    private static void DialogBoxSelectedValue(JFXPanel fxPanel)
    {
        Platform.runLater(() -> {
            HBox layout = new HBox(10); // Create an HBox with spacing
            Button button = new Button("");
            // Creating three buttons using the loop logic 
            for (int i = 1; i <= 3; i++) {
                if(i==1)
                {
                // naming, setting height, width and color of the buttons. 
                button = new Button("Vegan");
                button.setPrefWidth(500);
                button.setPrefHeight(200);
                button.setStyle("-fx-background-color: #4E7C7D; -fx-text-fill: white;-fx-font-size: 20px;-fx-font-weight: bold;");
            }
            if(i==2)
            {
                button = new Button("Gluten-Free");
                button.setPrefWidth(500);
                button.setPrefHeight(200);
                button.setStyle("-fx-background-color: #D6286C; -fx-text-fill: white;-fx-font-size: 20px;-fx-font-weight: bold;");
            }
            if(i==3)
            {
                button = new Button("Paleo-Diet");
                button.setPrefWidth(500);
                button.setPrefHeight(200);
                button.setStyle("-fx-background-color: #F0B608; -fx-text-fill: white;-fx-font-size: 20px;-fx-font-weight: bold;");
            }
                
                button.setOnAction(event -> 
                {
                    // Creating a TextInputDialog box
                    TextInputDialog dialog = new TextInputDialog("");
                    dialog.setTitle("Enter Value");
                    dialog.setHeaderText("Enter your selected option:");
                    dialog.setContentText("Value:");
                    // prompting for input 
                    Optional<String> result = dialog.showAndWait();

                    result.ifPresent(value -> 
                    {
                        value = value.toLowerCase();
                        // checking for values 
                        if (value.equals("vegan") || value.equals("gluten-free")|| value.equals("paleo-diet")) 
                        {
                            // Displaying a message indicating the selected option
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Option Selected!!");
                            alert.setHeaderText(null);
                            alert.setContentText("You selected: " + value);
                            alert.showAndWait();
                        } else {
                            // Displaying a message for an invalid option
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Select Again !! Use *Hyphen*");
                            alert.setHeaderText(null);
                            alert.setContentText("Nothing Selected: " + value);
                            alert.showAndWait();
                        }
                        if(value.equals("vegan")) // if user enter vegan, calling the method from vegan class
                        {
                            Vegan.initAndShowFXVegan();
                        
                        }
                        if(value.equals("gluten-free")) // if user enter Gluten-free, calling the method from Gluten-free class
                        {
                            GlutenFree.initAndShowFXGlutenFree();
                        }
                        if(value.equals("paleo-diet"))  // if user enter Plaeo-diet, calling the method from Paleo-diet class
                        {
                            PaleoDiet.initAndShowFXPaleoDiet();
                        }
                        
                    });
                    
                });

                layout.getChildren().add(button);
            }

            Scene scene = new Scene(layout, 300, 200);
            fxPanel.setScene(scene);
        });
        
    }
}