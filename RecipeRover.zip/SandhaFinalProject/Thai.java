                                        /**********************************************************************
                                        ***  Project Name : CS 200 Programming Assignment (Final Project)   ***
                                        ***  Author       : Seerat Sandha                                   ***
                                        ***  Date         : 12/08/2023                                      ***
                                        ***********************************************************************/  





import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.util.Comparator;
import java.util.Collections;
import java.awt.GridLayout;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;


public class Thai extends CuisineOptionSelected
{
    static JFrame frame = new JFrame("NoDiet Option");
    static JPanel panel = new JPanel();
    static int optionCounter = 1;

    

    public static void initAndShowFXThai() {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1, 1);

        JPanel fxPanel = new JPanel();
        frame.add(fxPanel);

        frame.setVisible(true);
        ThaiDishesPrint();
    }

/* 
 * Method to read the data from the CSV file containing the data for Thai Dishes from row 12 to 16. 
 * In which row 1 contain the headers 
 * */
    private static void ThaiDishesPrint() {
    BufferedReader readBuffer = null;
    try {
        String inputLine;
        readBuffer = new BufferedReader(new FileReader("C:\\Users\\sand4927\\Cuisines Data (Sandha).csv"));

        // Reading and ignoring the header row
        readBuffer.readLine();

        ArrayList<ArrayList<String>> data = new ArrayList<>();

        int rowsToDisplay = 5;
        int currentRow = 1;

        
// Reading and ignoring the header row
readBuffer.readLine();

// Adjusting the condition to read from the 12th to the 16 th row and skip the first row
while ((inputLine = readBuffer.readLine()) != null && currentRow < rowsToDisplay+ 10) {
    currentRow++;
    if (currentRow > 10) {
        ArrayList<String> rowData = CSVtoArrayList(inputLine);
        data.add(rowData);
    }
}




        // Create a copy of the data for display
        ArrayList<ArrayList<String>> displayData = new ArrayList<>(data);

        // Sort the display data alphabetically based on dish names
        Collections.sort(displayData, Comparator.comparing(row -> row.get(1), String.CASE_INSENSITIVE_ORDER)); // by stackOverflow.com


        // Display only the five Thai dishes with data
        displayDishNames(displayData, currentRow);

        // Get user input for the selected dish
        boolean checkValidNumber = true;
        while(checkValidNumber)
        {
        int selectedDishNumber = getUserInput("Enter the number of the dish to view details:");

        if (selectedDishNumber >= 1 && selectedDishNumber <=5)
        {
            // Display detailed information for the selected dish
            displayDishDetails(displayData.get(selectedDishNumber - 1));
            checkValidNumber = false;
        } else 
        {
            JOptionPane.showMessageDialog(null, "Invalid dish number. Please try again.");
        }
    }

    } catch (IOException e) {
        System.out.println("Ran into an IO error");
        e.printStackTrace();
    } finally {
        try {
            if (readBuffer != null) {
                readBuffer.close();
            }
        } catch (IOException readException) {
            System.out.println("Ran into an error reading the file");
            readException.printStackTrace();
        }
    }
}


    private  static int getUserInput(String message) {
        String userInput = JOptionPane.showInputDialog(null, message);
        return Integer.parseInt(userInput);
    }

    private  static void displayDishNames(ArrayList<ArrayList<String>> data, int currentRow) {
    ArrayList<JLabel> sortedThaiDishes = new ArrayList<>();

    
// Sort the data alphabetically based on dish names
Collections.sort(data, Comparator.comparing(row -> row.get(1).trim(), String.CASE_INSENSITIVE_ORDER));


// Display the sorted dishes
for (ArrayList<String> row : data) {
    String namesOnly = row.get(1);
    JLabel label = new JLabel(" ( " + optionCounter + ") " + namesOnly + "     ");
    optionCounter++;
    label.setFont(new Font("Agency FB", Font.BOLD, 20));
    panel.add(label);
}


    // Add the sorted labels to your panel
    SwingUtilities.invokeLater(() -> {
        for (JLabel label : sortedThaiDishes) {
            label.setFont(new Font("Agency FB", Font.BOLD, 20));
            panel.add(label);
        }

        frame.add(panel);

        frame.pack(); // Pack the frame to fit its contents
        frame.setVisible(true);
        frame.setSize(1920, 1080);
        frame.setVisible(true);
    });
}



    private  static void displayDishDetails(ArrayList<String> dishData) {
    // Clear the panel before displaying dish details
    panel.removeAll();

    ArrayList<JTextArea> dishDetails = new ArrayList<>();
    dishDetails.add(createTextArea("Prep Time: " + dishData.get(2)));
    dishDetails.add(createTextArea("Cook Time: " + dishData.get(3)));
    dishDetails.add(createTextArea("Total Time: " + dishData.get(4)));
    dishDetails.add(createTextArea("Servings: " + dishData.get(5)));
    dishDetails.add(createTextArea("Ingredients: " + dishData.get(6)));
    dishDetails.add(createTextArea("Directions: " + dishData.get(7)));

    // Set up a GridLayout for the panel
    panel.setLayout(new GridLayout(dishDetails.size(), 1));

    // Add the text areas to the panel
    for (JTextArea textArea : dishDetails) {
        panel.add(new JScrollPane(textArea));
    }

    frame.add(panel);

    frame.pack(); // Pack the frame to fit its contents
    frame.setVisible(true);
    frame.setSize(1920, 1080);
    frame.setVisible(true);
}

private static JTextArea createTextArea(String text) {
    JTextArea textArea = new JTextArea(text);
    textArea.setFont(new Font("Arial", Font.PLAIN, 16));
    textArea.setEditable(false);
    textArea.setLineWrap(true);
    textArea.setWrapStyleWord(true);
    return textArea;
}

    // Utility which converts CSV to ArrayList using Split operation
    private static ArrayList<String> CSVtoArrayList(String CSVFileName) {
    ArrayList<String> arrlist = new ArrayList<>();

    if (CSVFileName != null) {
        // Use a regular expression to split the CSV line while ignoring commas within quotes
        String[] splitData = CSVFileName.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);

        for (int i = 0; i < splitData.length; i++) {
            if (splitData[i].length() == 0) {
                splitData[i] = "0";
            }
            if (splitData[i] != null && splitData[i].length() != 0) {
                arrlist.add(splitData[i].trim());
            }
        }
    }
    return arrlist;
}
}
